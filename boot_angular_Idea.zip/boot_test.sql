/*
Data Transfer

Source Server         : localhost-mysql
Source Host           : localhost:3306
Source Database       : boot_test

*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tab_dep
-- ----------------------------
DROP TABLE IF EXISTS `tab_dep`;
CREATE TABLE `tab_dep` (
  `dep_id` int(11) NOT NULL AUTO_INCREMENT,
  `dep_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`dep_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of tab_dept
-- ----------------------------
INSERT INTO `tab_dep` VALUES ('1', 'sales');
INSERT INTO `tab_dep` VALUES ('2', 'boss');
INSERT INTO `tab_dep` VALUES ('3', 'engineer');
INSERT INTO `tab_dep` VALUES ('4', 'accountant');
INSERT INTO `tab_dep` VALUES ('5', 'assist');
INSERT INTO `tab_dep` VALUES ('6', 'front desk');
INSERT INTO `tab_dep` VALUES ('7', 'intern');

-- ----------------------------
-- Table structure for tab_emp
-- ----------------------------
DROP TABLE IF EXISTS `tab_emp`;
CREATE TABLE `tab_emp` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `d_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `fk_emp_dep` (`d_id`),
  CONSTRAINT `fk_emp_dep` FOREIGN KEY (`d_id`) REFERENCES `tab_dep` (`dep_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of tab_emp
-- ----------------------------
INSERT INTO `tab_emp` VALUES ('31', 'James', 'male', 'justinwpro@gmail.com', null);
