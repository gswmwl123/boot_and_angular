package com.joe.angularweb.service;

import com.joe.angularweb.model.Employee;

import java.util.List;


public interface EmployeeService {

    Employee findOne(Integer empId);

    List<Employee> findAll();

    Employee save(Employee employee);

    List<Employee> findByGender(String gender);

    void deleteByEmpId(Integer empId);


}
