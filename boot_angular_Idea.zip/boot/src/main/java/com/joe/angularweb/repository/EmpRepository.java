package com.joe.angularweb.repository;

import com.joe.angularweb.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;


public interface EmpRepository extends JpaRepository<Employee,Integer> {
    //sex
    List<Employee> findByGender(String gender);
}
